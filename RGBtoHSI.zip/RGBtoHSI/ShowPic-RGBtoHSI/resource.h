//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShowPic.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SHOWPITYPE                  129
#define IDD_DIALOG1                     130
#define IDD_RGBtoHSI                    131
#define IDC_huemin                      1000
#define IDC_huemax                      1001
#define IDC_saturationmin               1002
#define IDC_saturationmax               1003
#define IDC_intensitymin                1004
#define IDC_intensitymax                1005
#define IDC_huemin2                     1006
#define IDC_huemax2                     1007
#define ID_MENUITEM32771                32771
#define ID_MENUITEM32772                32772
#define ID_MENUITEM32773                32773
#define ID_Histogram                    32774
#define ID_ShowHistogram                32775
#define ID_RGBtoHSI                     32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
