#if !defined(AFX_RGBTOHSI_H__417C25FD_7DF8_4AB9_BFEB_A24B74A2FF4A__INCLUDED_)
#define AFX_RGBTOHSI_H__417C25FD_7DF8_4AB9_BFEB_A24B74A2FF4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RGBtoHSI.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRGBtoHSI dialog

class CRGBtoHSI : public CDialog
{
// Construction
public:
	CRGBtoHSI(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRGBtoHSI)
	enum { IDD = IDD_RGBtoHSI };
	int		m_huemax;
	int		m_huemax2;
	int		m_huemin;
	int		m_huemin2;
	int		m_intensitymax;
	int		m_intensitymin;
	int		m_saturationmax;
	int		m_saturationmin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRGBtoHSI)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRGBtoHSI)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RGBTOHSI_H__417C25FD_7DF8_4AB9_BFEB_A24B74A2FF4A__INCLUDED_)
